<template>
  <div class="mobile-shell">
    <div class="mobile-card">
      <h1>현장관리자 모바일 운영</h1>
      <p class="helper">배포 목록에서 선택한 항목을 기준으로 TBM 시작/위치 ping/서명 현황을 운영합니다.</p>

      <div class="grid-two">
        <button class="mobile-secondary" :disabled="loading || !distributionId" @click="loadDistribution">
          선택 배포 새로고침
        </button>
        <button class="mobile-secondary" :disabled="loading || !distributionId" @click="startTbm">
          TBM 시작
        </button>
      </div>

      <button class="mobile-primary" :disabled="loading" @click="pingPresence">관리자 위치 Ping</button>

      <p v-if="message" :class="['mobile-message', messageType]">{{ message }}</p>

      <section class="status-box" v-if="auth.isTestPersonaMode && !auth.user?.site_id">
        <div><strong>테스트 site context</strong></div>
        <div class="helper">현재 계정은 site_id가 없어 테스트용 site context가 필요합니다.</div>
        <div class="grid-two">
          <select v-model.number="selectedSiteContextId" @change="onChangeSiteContext">
            <option :value="0">현장 선택</option>
            <option v-for="s in siteOptions" :key="s.id" :value="s.id">
              {{ s.site_name }} (#{{ s.id }})
            </option>
          </select>
          <button class="mobile-secondary" :disabled="siteOptionsLoading" @click="loadSiteOptions">
            {{ siteOptionsLoading ? "조회 중..." : "현장 목록 새로고침" }}
          </button>
        </div>
        <div v-if="siteOptions.length === 0" class="site-context-hint">
          현장 목록이 비어 있습니다. 토큰 만료, 권한, 또는 sites 데이터 상태를 확인하세요.
        </div>
      </section>

      <section class="status-box" v-if="recentDistributionIds.length > 0">
        <div><strong>최근 배포 선택</strong></div>
        <div class="recent-actions">
          <button
            v-for="id in recentDistributionIds"
            :key="id"
            class="mobile-secondary"
            @click="selectDistribution(id)"
          >
            배포 #{{ id }}
          </button>
        </div>
      </section>

      <section class="status-box" v-else>
        <div><strong>안내</strong></div>
        <div>배포 목록은 문서 화면에서 진입하거나 URL에 `?distribution_id=ID`를 포함해 접근하세요.</div>
      </section>

      <section v-if="distribution" class="status-box">
        <div><strong>현재 배포:</strong> #{{ distribution.id }}</div>
        <div><strong>TBM 상태:</strong> {{ distribution.is_tbm_active ? "시작됨" : "미시작" }}</div>
        <div><strong>TBM 시작시각:</strong> {{ distribution.tbm_started_at ?? "-" }}</div>
        <div><strong>대상 인원:</strong> {{ stats.total }}</div>
        <div><strong>시작 서명:</strong> {{ stats.startSigned }}</div>
        <div><strong>종료 서명:</strong> {{ stats.endSigned }}</div>
        <div><strong>ISSUE:</strong> {{ stats.issueCount }}</div>
      </section>

      <ul class="mobile-list" v-if="distribution?.workers?.length">
        <li v-for="w in distribution.workers" :key="w.id">
          <div><strong>person #{{ w.person_id }}</strong></div>
          <div>상태: {{ w.ack_status }}</div>
          <div>시작: {{ w.start_signed_at ?? "-" }}</div>
          <div>종료: {{ w.end_signed_at ?? "-" }}</div>
          <div>issue: {{ w.issue_flag ? "Y" : "N" }}</div>
          <div><strong>access_token:</strong> {{ w.access_token }}</div>
          <div class="worker-actions">
            <button class="mobile-secondary" @click="copyToken(w.access_token)">토큰 복사</button>
            <button class="mobile-secondary" @click="copyWorkerLink(w.access_token)">근로자 링크 복사</button>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { useRoute } from "vue-router";
import { api } from "@/services/api";
import { useAuthStore } from "@/stores/auth";

interface DistributionWorker {
  id: number;
  person_id: number;
  access_token: string;
  ack_status: string;
  start_signed_at: string | null;
  end_signed_at: string | null;
  issue_flag: boolean;
}

interface DistributionDetail {
  id: number;
  site_id: number;
  is_tbm_active: boolean;
  tbm_started_at: string | null;
  workers: DistributionWorker[];
}

interface SiteOption {
  id: number;
  site_name: string;
}

const auth = useAuthStore();
const route = useRoute();
const distributionId = ref<number | null>(null);
const distribution = ref<DistributionDetail | null>(null);
const loading = ref(false);
const message = ref("");
const messageType = ref<"error" | "success">("success");
const RECENT_DIST_KEY = "besma_recent_distribution_ids";
const recentDistributionIds = ref<number[]>([]);
const siteOptions = ref<SiteOption[]>([]);
const selectedSiteContextId = ref<number>(auth.effectiveSiteId ?? 0);
const siteOptionsLoading = ref(false);

const stats = computed(() => {
  const workers = distribution.value?.workers ?? [];
  return {
    total: workers.length,
    startSigned: workers.filter((w) => !!w.start_signed_at).length,
    endSigned: workers.filter((w) => !!w.end_signed_at).length,
    issueCount: workers.filter((w) => w.issue_flag).length,
  };
});

function setError(text: string) {
  messageType.value = "error";
  message.value = text;
}

function setSuccess(text: string) {
  messageType.value = "success";
  message.value = text;
}

async function copyText(value: string, successText: string) {
  try {
    await navigator.clipboard.writeText(value);
    setSuccess(successText);
  } catch {
    setError("클립보드 복사에 실패했습니다.");
  }
}

function copyToken(token: string) {
  copyText(token, "근로자 access_token을 복사했습니다.");
}

function copyWorkerLink(token: string) {
  const link = `${window.location.origin}/worker/mobile?access_token=${encodeURIComponent(token)}`;
  copyText(link, "근로자 접속 링크를 복사했습니다.");
}

function loadRecentDistributionIds() {
  try {
    const raw = localStorage.getItem(RECENT_DIST_KEY);
    if (!raw) {
      recentDistributionIds.value = [];
      return;
    }
    const parsed = JSON.parse(raw) as number[];
    recentDistributionIds.value = parsed.filter((v) => Number.isFinite(v) && v > 0).slice(0, 10);
  } catch {
    recentDistributionIds.value = [];
  }
}

function saveRecentDistributionId(id: number) {
  const current = recentDistributionIds.value.filter((x) => x !== id);
  recentDistributionIds.value = [id, ...current].slice(0, 10);
  localStorage.setItem(RECENT_DIST_KEY, JSON.stringify(recentDistributionIds.value));
}

function selectDistribution(id: number) {
  distributionId.value = id;
  loadDistribution();
}

async function loadSiteOptions() {
  if (!auth.isTestPersonaMode) return;
  siteOptionsLoading.value = true;
  try {
    const res = await api.get("/sites");
    siteOptions.value = (res.data as SiteOption[]) ?? [];
    if (siteOptions.value.length === 0) {
      setError("현장 목록이 비어 있습니다. site 데이터가 있는지 확인하세요.");
    }
  } catch (err: any) {
    siteOptions.value = [];
    setError(
      err?.response?.data?.detail ??
        "현장 목록 조회 실패: 다시 로그인 후 재시도하거나 API 연결 상태를 확인하세요.",
    );
  } finally {
    siteOptionsLoading.value = false;
  }
}

function onChangeSiteContext() {
  if (selectedSiteContextId.value > 0) {
    auth.setTestSiteContext(selectedSiteContextId.value);
    setSuccess(`테스트 site context를 #${selectedSiteContextId.value}로 설정했습니다.`);
  } else {
    auth.setTestSiteContext(null);
  }
}

async function loadDistribution() {
  if (!distributionId.value) return;
  loading.value = true;
  try {
    const res = await api.get(`/daily-work-plans/distributions/${distributionId.value}`);
    distribution.value = res.data;
    saveRecentDistributionId(distributionId.value);
    setSuccess("배포 상세를 불러왔습니다.");
  } catch (err: any) {
    setError(err?.response?.data?.detail ?? "배포 조회 실패");
  } finally {
    loading.value = false;
  }
}

async function startTbm() {
  if (!distributionId.value) return;
  loading.value = true;
  try {
    await api.post(`/daily-work-plans/distributions/${distributionId.value}/start-tbm`);
    setSuccess("TBM 시작 처리 완료");
    await loadDistribution();
  } catch (err: any) {
    setError(err?.response?.data?.detail ?? "TBM 시작 실패");
  } finally {
    loading.value = false;
  }
}

async function pingPresence() {
  loading.value = true;
  try {
    if (!navigator.geolocation) throw new Error("위치 기능이 지원되지 않습니다.");
    const pos = await new Promise<GeolocationPosition>((resolve, reject) =>
      navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 10000 }),
    );
    const siteId = auth.user?.site_id ?? distribution.value?.site_id ?? auth.effectiveSiteId;
    if (!siteId) {
      throw new Error("site context가 없습니다. 실제 SITE 계정으로 로그인하거나 테스트 site context를 선택하세요.");
    }
    await api.post("/daily-work-plans/admin-presence/ping", {
      site_id: siteId,
      lat: pos.coords.latitude,
      lng: pos.coords.longitude,
    });
    setSuccess("관리자 위치 ping 완료");
  } catch (err: any) {
    setError(err?.response?.data?.detail ?? err?.message ?? "관리자 ping 실패");
  } finally {
    loading.value = false;
  }
}

onMounted(() => {
  loadRecentDistributionIds();
  loadSiteOptions();
  const queryDistributionId = Number(route.query.distribution_id);
  if (Number.isFinite(queryDistributionId) && queryDistributionId > 0) {
    distributionId.value = queryDistributionId;
    loadDistribution();
  }
});
</script>

<style scoped>
.mobile-shell {
  min-height: 100%;
}

.mobile-card {
  max-width: 760px;
  margin: 0 auto;
  background: #fff;
  border-radius: 12px;
  padding: 14px;
}

h1 {
  font-size: 20px;
  margin: 0 0 8px;
}

.helper {
  margin: 0 0 10px;
  color: #6b7280;
  font-size: 13px;
}

.grid-two {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
}

.mobile-primary,
.mobile-secondary {
  width: 100%;
  min-height: 44px;
  border: none;
  border-radius: 10px;
  font-size: 16px;
}

.mobile-primary {
  background: #2563eb;
  color: #fff;
}

.mobile-secondary {
  background: #e5e7eb;
}

.mobile-message {
  margin-top: 10px;
  font-weight: 600;
}

.mobile-message.error {
  color: #dc2626;
}

.mobile-message.success {
  color: #16a34a;
}

.status-box {
  margin-top: 10px;
  border: 1px solid #d1d5db;
  border-radius: 10px;
  padding: 10px;
  display: grid;
  gap: 4px;
}

.recent-actions {
  margin-top: 8px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
}

.mobile-list {
  list-style: none;
  padding: 0;
  margin: 10px 0 0;
  display: grid;
  gap: 8px;
}

.mobile-list li {
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  padding: 8px;
}

.worker-actions {
  margin-top: 8px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
}

.site-context-hint {
  margin-top: 8px;
  color: #b45309;
  font-size: 13px;
}

@media (max-width: 720px) {
  .grid-two {
    grid-template-columns: 1fr;
  }

  .recent-actions {
    grid-template-columns: 1fr;
  }

  .worker-actions {
    grid-template-columns: 1fr;
  }
}
</style>
