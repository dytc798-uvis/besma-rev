<template>
  <div class="card">
    <div class="card-title">HQ TBM 모니터</div>
    <div class="toolbar">
      <div class="toolbar-filters">
        <input v-model.number="documentId" type="text" placeholder="document_id 입력" />
      </div>
      <div class="toolbar-actions">
        <button class="secondary" @click="loadDocuments">문서 새로고침</button>
        <button class="primary" :disabled="!documentId" @click="loadSummary">TBM 요약 조회</button>
      </div>
    </div>

    <p v-if="message" class="monitor-message">{{ message }}</p>

    <div class="monitor-grid" v-if="summary">
      <div class="mini-card"><strong>교육인원</strong><div>{{ summary.education_count }}</div></div>
      <div class="mini-card"><strong>시작서명 완료</strong><div>{{ startedCount }}</div></div>
      <div class="mini-card"><strong>종료서명 완료</strong><div>{{ completedCount }}</div></div>
      <div class="mini-card"><strong>ISSUE 인원</strong><div>{{ issueCount }}</div></div>
    </div>

    <div class="toolbar" v-if="summary">
      <div>document #{{ summary.document_id }}</div>
      <div class="toolbar-actions">
        <button class="primary" @click="goTbmView">TBM 보기</button>
        <button class="secondary" @click="goDocumentDetail">문서 상세</button>
      </div>
    </div>

    <table class="basic-table" v-if="summary">
      <thead>
        <tr>
          <th>근로자</th>
          <th>ack_status</th>
          <th>시작서명</th>
          <th>종료서명</th>
          <th>end_status</th>
          <th>issue</th>
          <th>시작 이미지</th>
          <th>종료 이미지</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="p in summary.participants" :key="p.person_id">
          <td>{{ p.name }}</td>
          <td>{{ p.ack_status }}</td>
          <td>{{ p.start_signed_at || "-" }}</td>
          <td>{{ p.end_signed_at || "-" }}</td>
          <td>{{ p.end_status || "-" }}</td>
          <td>{{ p.issue_flag ? "Y" : "N" }}</td>
          <td>
            <img v-if="p.start_signature_data" :src="p.start_signature_data" alt="start-sign" class="sign-thumb" />
            <span v-else>-</span>
          </td>
          <td>
            <img v-if="p.end_signature_data" :src="p.end_signature_data" alt="end-sign" class="sign-thumb" />
            <span v-else>-</span>
          </td>
        </tr>
      </tbody>
    </table>

    <div v-if="summary?.table_rows?.length" class="monitor-section">
      <h3>TBM 작업/위험요인/대책</h3>
      <table class="basic-table">
        <thead>
          <tr>
            <th>작업내용</th>
            <th>위험요인</th>
            <th>대책</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(row, idx) in summary.table_rows" :key="idx">
            <td>{{ row.work_description || "-" }}</td>
            <td>{{ row.risk_factor }}</td>
            <td>{{ row.counterplan }}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <h3 style="margin-top: 16px">최근 문서</h3>
    <table class="basic-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>제목</th>
          <th>상태</th>
          <th>액션</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="d in documents" :key="d.id">
          <td>{{ d.id }}</td>
          <td>{{ d.title }}</td>
          <td>{{ d.current_status }}</td>
          <td>
            <button class="secondary" @click="pickDocument(d.id)">선택</button>
          </td>
        </tr>
        <tr v-if="documents.length === 0">
          <td colspan="4" style="text-align: center">문서가 없습니다.</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { useRouter } from "vue-router";
import { api } from "@/services/api";

interface DocItem {
  id: number;
  title: string;
  current_status: string;
}

interface Participant {
  person_id: number;
  name: string;
  ack_status: string;
  start_signed_at: string | null;
  end_signed_at: string | null;
  end_status: string | null;
  issue_flag: boolean;
  start_signature_data?: string | null;
  end_signature_data?: string | null;
}

interface Summary {
  document_id: number;
  education_count: number;
  participants: Participant[];
  table_rows?: Array<{
    work_description: string | null;
    risk_factor: string;
    counterplan: string;
  }>;
}

const router = useRouter();
const documentId = ref<number | null>(null);
const documents = ref<DocItem[]>([]);
const summary = ref<Summary | null>(null);
const message = ref("");

const startedCount = computed(() => summary.value?.participants.filter((p) => !!p.start_signed_at).length ?? 0);
const completedCount = computed(() => summary.value?.participants.filter((p) => !!p.end_signed_at).length ?? 0);
const issueCount = computed(() => summary.value?.participants.filter((p) => p.issue_flag).length ?? 0);

async function loadDocuments() {
  const res = await api.get("/documents");
  documents.value = (res.data as DocItem[]).slice(0, 30);
}

async function loadSummary() {
  if (!documentId.value) return;
  message.value = "";
  try {
    const res = await api.get(`/documents/${documentId.value}/tbm-summary`);
    summary.value = res.data;
  } catch (err: any) {
    message.value = err?.response?.data?.detail ?? "TBM 요약 조회 실패";
  }
}

function pickDocument(id: number) {
  documentId.value = id;
  loadSummary();
}

function goTbmView() {
  if (!documentId.value) return;
  router.push({ name: "hq-safe-document-tbm-view", params: { id: documentId.value } });
}

function goDocumentDetail() {
  if (!documentId.value) return;
  router.push({ name: "hq-safe-document-detail", params: { id: documentId.value } });
}

onMounted(loadDocuments);
</script>

<style scoped>
.monitor-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
  margin-bottom: 12px;
}

.mini-card {
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 10px;
  background: #fafafa;
}

.mini-card div {
  font-size: 20px;
  font-weight: 700;
}

.monitor-message {
  color: #ef4444;
}

.monitor-section {
  margin-top: 16px;
}

.sign-thumb {
  width: 120px;
  max-height: 48px;
  object-fit: contain;
  border: 1px solid #d1d5db;
  background: #fff;
}

@media (max-width: 1024px) {
  .monitor-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>
