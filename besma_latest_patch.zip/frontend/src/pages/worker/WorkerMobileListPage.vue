<template>
  <div class="mobile-shell">
    <div class="mobile-card">
      <h1>근로자 작업일보</h1>
      <p class="helper">
        로그인한 근로자는 자동으로 내 목록을 조회합니다. (예외적으로 링크 토큰 진입도 지원합니다.)
      </p>
      <button class="mobile-primary" :disabled="loading" @click="loadMyPlans">
        {{ loading ? "조회 중..." : "내 배포 목록 조회" }}
      </button>
      <p v-if="message" class="mobile-message">{{ message }}</p>
      <ul class="mobile-list" v-if="plans.length > 0">
        <li v-for="item in plans" :key="item.distribution_id">
          <div><strong>배포 #{{ item.distribution_id }}</strong></div>
          <div>작업일: {{ item.work_date }}</div>
          <div>상태: {{ item.ack_status }}</div>
          <button class="mobile-secondary" @click="goDetail(item.distribution_id)">상세/서명</button>
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { api } from "@/services/api";
import { useAuthStore } from "@/stores/auth";

interface WorkerPlanItem {
  distribution_id: number;
  work_date: string;
  ack_status: string;
}

const route = useRoute();
const router = useRouter();
const auth = useAuthStore();
const accessToken = ref<string>((route.query.access_token as string) || "");
const plans = ref<WorkerPlanItem[]>([]);
const loading = ref(false);
const message = ref("");

async function loadMyPlans() {
  loading.value = true;
  message.value = "";
  try {
    const params = accessToken.value ? { access_token: accessToken.value } : undefined;
    const res = await api.get("/worker/my-daily-work-plans", { params });
    plans.value = res.data;
    if (plans.value.length === 0) {
      message.value = "조회된 배포가 없습니다. 관리자에게 확인하세요.";
    }
  } catch (err: any) {
    const detail = err?.response?.data?.detail;
    if (detail === "Worker login or access_token is required") {
      message.value =
        "근로자 로그인 또는 전용 링크(access_token)가 필요합니다. 예: /worker/mobile?access_token=...";
    } else {
      message.value = detail ?? "조회 중 오류가 발생했습니다.";
    }
  } finally {
    loading.value = false;
  }
}

function goDetail(distributionId: number) {
  router.push({
    name: "worker-mobile-detail",
    params: { distributionId },
    query: accessToken.value ? { access_token: accessToken.value } : undefined,
  });
}

if (auth.isAuthenticated || accessToken.value) {
  loadMyPlans();
} else {
  message.value =
    "근로자 로그인 또는 전용 링크(access_token)가 필요합니다. 예: /worker/mobile?access_token=...";
}
</script>

<style scoped>
.mobile-shell {
  min-height: 100vh;
  padding: 12px;
  background: #f3f4f6;
}

.mobile-card {
  max-width: 560px;
  margin: 0 auto;
  background: #fff;
  border-radius: 12px;
  padding: 16px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
}

h1 {
  margin: 0 0 6px;
  font-size: 20px;
}

.helper {
  margin: 0 0 12px;
  color: #6b7280;
  font-size: 13px;
}

.mobile-primary,
.mobile-secondary {
  width: 100%;
  min-height: 44px;
  border: none;
  border-radius: 10px;
  font-size: 16px;
}

.mobile-primary {
  background: #2563eb;
  color: #fff;
}

.mobile-secondary {
  margin-top: 8px;
  background: #e5e7eb;
}

.mobile-message {
  margin-top: 10px;
  color: #ef4444;
  font-size: 14px;
}

.mobile-list {
  list-style: none;
  padding: 0;
  margin: 12px 0 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.mobile-list li {
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  padding: 10px;
  background: #fafafa;
}
</style>
