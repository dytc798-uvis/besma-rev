from datetime import date

from sqlalchemy.orm import Session

from app.config.security import get_password_hash
from app.core.database import SessionLocal, init_db
from app.core.enums import Role, UIType
from app.modules.document_settings.models import DocumentTypeMaster, SubmissionCycle
from app.modules.sites.models import Site
from app.modules.users.models import User
from app.modules.workers.models import Employment, Person


def seed_sites(db: Session) -> None:
    if db.query(Site).count() > 0:
        return

    sites = [
        Site(
            site_code="SITE001",
            site_name="부현전기 서울 현장",
            client_name="부현전기",
            start_date=date(2025, 1, 1),
            status="ACTIVE",
            manager_name="현장관리자1",
            description="서울 지역 주요 현장",
        ),
        Site(
            site_code="SITE002",
            site_name="부현전기 부산 현장",
            client_name="부현전기",
            start_date=date(2025, 3, 1),
            status="ACTIVE",
            manager_name="현장관리자2",
            description="부산 지역 주요 현장",
        ),
    ]
    db.add_all(sites)
    db.commit()


def seed_users(db: Session) -> None:
    site1 = db.query(Site).filter(Site.site_code == "SITE001").first()
    site2 = db.query(Site).filter(Site.site_code == "SITE002").first()

    password_plain = "P@ssw0rd!"

    # 기존 DB를 재사용하는 경우에도 로그인 가능하도록 "샘플 계정은 upsert" 한다.
    # (MVP에서 마이그레이션 체계가 없기 때문에, 이전 해시 포맷이 남아 500이 나지 않도록 보정)
    # worker 로그인 데모 계정을 위해 person/employment를 보장한다.
    worker_person_1 = db.query(Person).filter(Person.phone_mobile == "01090000001").first()
    if worker_person_1 is None:
        worker_person_1 = Person(name="근로자1", phone_mobile="01090000001")
        db.add(worker_person_1)
        db.flush()
        db.add(
            Employment(
                person_id=worker_person_1.id,
                source_type="employee",
                employee_code="W001",
                site_code=site1.site_code if site1 else None,
                is_active=True,
            )
        )

    worker_person_2 = db.query(Person).filter(Person.phone_mobile == "01090000002").first()
    if worker_person_2 is None:
        worker_person_2 = Person(name="근로자2", phone_mobile="01090000002")
        db.add(worker_person_2)
        db.flush()
        db.add(
            Employment(
                person_id=worker_person_2.id,
                source_type="employee",
                employee_code="W002",
                site_code=site2.site_code if site2 else None,
                is_active=True,
            )
        )

    desired = [
        dict(
            name="본사안전1",
            login_id="hqsafe1",
            department="안전보건실",
            role=Role.HQ_SAFE,  # 기본 role 유지 (관리자 분리는 다음 단계에서 정책 확정 후 적용 가능)
            ui_type=UIType.HQ_SAFE,
            site_id=None,
        ),
        dict(
            name="본사안전2",
            login_id="hqsafe2",
            department="안전보건실",
            role=Role.HQ_SAFE,
            ui_type=UIType.HQ_SAFE,
            site_id=None,
        ),
        dict(
            name="현장관리자1",
            login_id="site01",
            department="현장",
            role=Role.SITE,
            ui_type=UIType.SITE,
            site_id=site1.id if site1 else None,
        ),
        dict(
            name="현장관리자2",
            login_id="site02",
            department="현장",
            role=Role.SITE,
            ui_type=UIType.SITE,
            site_id=site2.id if site2 else None,
        ),
        dict(
            name="본사타부서1",
            login_id="hqother1",
            department="경영지원",
            role=Role.HQ_OTHER,
            ui_type=UIType.HQ_OTHER,
            site_id=None,
            person_id=None,
        ),
        dict(
            name=worker_person_1.name,
            login_id="worker01",
            department="현장근로",
            role=Role.WORKER,
            ui_type=UIType.SITE,
            site_id=site1.id if site1 else None,
            person_id=worker_person_1.id,
        ),
        dict(
            name=worker_person_2.name,
            login_id="worker02",
            department="현장근로",
            role=Role.WORKER,
            ui_type=UIType.SITE,
            site_id=site2.id if site2 else None,
            person_id=worker_person_2.id,
        ),
    ]

    for u in desired:
        existing = db.query(User).filter(User.login_id == u["login_id"]).first()
        if existing:
            existing.name = u["name"]
            existing.department = u["department"]
            existing.role = u["role"]
            existing.ui_type = u["ui_type"]
            existing.site_id = u["site_id"]
            existing.person_id = u.get("person_id")
            existing.is_active = True
            existing.password_hash = get_password_hash(password_plain)
        else:
            db.add(
                User(
                    name=u["name"],
                    login_id=u["login_id"],
                    password_hash=get_password_hash(password_plain),
                    department=u["department"],
                    role=u["role"],
                    ui_type=u["ui_type"],
                    site_id=u["site_id"],
                    person_id=u.get("person_id"),
                    is_active=True,
                )
            )
    db.commit()


def run_seed() -> None:
    init_db()
    db = SessionLocal()
    try:
        seed_sites(db)
        seed_users(db)
        seed_document_cycle_masters(db)
        seed_document_type_masters(db)
    finally:
        db.close()


def seed_document_cycle_masters(db: Session) -> None:
    if db.query(SubmissionCycle).count() > 0:
        return

    cycles = [
        SubmissionCycle(code="DAILY", name="일간", sort_order=10, is_auto_generatable=True),
        SubmissionCycle(code="WEEKLY", name="주간", sort_order=20, is_auto_generatable=True),
        SubmissionCycle(code="MONTHLY", name="월간", sort_order=30, is_auto_generatable=True),
        SubmissionCycle(code="QUARTERLY", name="분기", sort_order=40, is_auto_generatable=True),
        SubmissionCycle(code="HALF_YEARLY", name="반기", sort_order=50, is_auto_generatable=True),
        SubmissionCycle(code="YEARLY", name="연간", sort_order=60, is_auto_generatable=True),
        SubmissionCycle(code="ADHOC", name="수시", sort_order=90, is_auto_generatable=False),
    ]
    db.add_all(cycles)
    db.commit()


def seed_document_type_masters(db: Session) -> None:
    if db.query(DocumentTypeMaster).count() > 0:
        return

    # 기존 Document.document_type(문자열) 값과 100% 일치해야 함:
    # LEGAL_DOC, DAILY_DOC, INSPECTION, OPINION_RELATED, BUDGET, ACCIDENT, ETC
    adhoc = db.query(SubmissionCycle).filter(SubmissionCycle.code == "ADHOC").first()
    daily = db.query(SubmissionCycle).filter(SubmissionCycle.code == "DAILY").first()

    if not adhoc or not daily:
        return

    types = [
        DocumentTypeMaster(
            code="LEGAL_DOC",
            name="법정서류",
            default_cycle_id=adhoc.id,
            generation_rule="ADHOC_MANUAL",
            generation_value=None,
            due_offset_days=None,
            is_required_default=False,
            sort_order=10,
        ),
        DocumentTypeMaster(
            code="DAILY_DOC",
            name="일상점검",
            default_cycle_id=daily.id,
            generation_rule="DAILY",
            generation_value=None,
            due_offset_days=0,
            is_required_default=True,
            sort_order=20,
        ),
        DocumentTypeMaster(
            code="INSPECTION",
            name="점검",
            default_cycle_id=adhoc.id,
            generation_rule="ADHOC_MANUAL",
            generation_value=None,
            due_offset_days=None,
            is_required_default=False,
            sort_order=30,
        ),
        DocumentTypeMaster(
            code="OPINION_RELATED",
            name="의견 관련",
            default_cycle_id=adhoc.id,
            generation_rule="ADHOC_MANUAL",
            generation_value=None,
            due_offset_days=None,
            is_required_default=False,
            sort_order=40,
        ),
        DocumentTypeMaster(
            code="BUDGET",
            name="예산",
            default_cycle_id=adhoc.id,
            generation_rule="ADHOC_MANUAL",
            generation_value=None,
            due_offset_days=None,
            is_required_default=False,
            sort_order=50,
        ),
        DocumentTypeMaster(
            code="ACCIDENT",
            name="사고",
            default_cycle_id=adhoc.id,
            generation_rule="ADHOC_MANUAL",
            generation_value=None,
            due_offset_days=None,
            is_required_default=False,
            sort_order=60,
        ),
        DocumentTypeMaster(
            code="ETC",
            name="기타",
            default_cycle_id=adhoc.id,
            generation_rule="ADHOC_MANUAL",
            generation_value=None,
            due_offset_days=None,
            is_required_default=False,
            sort_order=70,
        ),
    ]

    db.add_all(types)
    db.commit()


if __name__ == "__main__":
    run_seed()

