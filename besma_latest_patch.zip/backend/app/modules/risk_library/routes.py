from datetime import date
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status

from app.core.auth import DbDep, get_current_user, oauth2_scheme_optional
from app.core.permissions import CurrentUserDep
from app.modules.risk_library.models import DailyWorkPlanItem
from app.modules.risk_library.service import (
    adopt_risks_for_plan_item_by_revision_ids,
    assemble_daily_work_plan_document,
    confirm_daily_work_plan,
    create_daily_work_plan,
    create_daily_work_plan_item,
    distribute_daily_work_plan,
    get_assembled_document_for_day,
    get_daily_work_plan,
    get_distribution_detail,
    get_worker_distribution_detail,
    list_plan_confirmations,
    list_distribution_workers,
    list_risk_refs_for_plan_item,
    list_worker_visible_distributions,
    ping_site_admin_presence,
    run_recommendation_for_plan_item,
    start_distribution_tbm,
    sign_worker_daily_work_plan,
    sign_worker_daily_work_plan_end,
)
from app.modules.sites.models import Site
from app.schemas.daily_work_plans import (
    AdoptRisksRequest,
    AdoptRisksResponse,
    AssembleDailyWorkPlanDocumentRequest,
    AssembleDailyWorkPlanDocumentResponse,
    GetAssembledDailyWorkPlanDocumentResponse,
    DailyWorkPlanConfirmResponse,
    DailyWorkPlanConfirmationResponse,
    DailyWorkPlanCreateRequest,
    DailyWorkPlanItemCreateRequest,
    DailyWorkPlanItemRiskRefResponse,
    DailyWorkPlanItemResponse,
    DailyWorkPlanResponse,
    RecommendRisksRequest,
    RecommendRisksResponse,
    DailyWorkPlanDistributeRequest,
    DailyWorkPlanDistributionDetailResponse,
    DailyWorkPlanDistributionResponse,
    SiteAdminPresencePingRequest,
    SiteAdminPresencePingResponse,
    StartTbmDistributionResponse,
    WorkerMyDailyWorkPlanDetailResponse,
    WorkerMyDailyWorkPlanListItem,
    WorkerSignEndDailyWorkPlanRequest,
    WorkerSignDailyWorkPlanRequest,
    WorkerSignDailyWorkPlanResponse,
)


router = APIRouter(tags=["daily-work-plans"])


def _get_optional_current_user(
    token: Annotated[str | None, Depends(oauth2_scheme_optional)],
    db: DbDep,
):
    if not token:
        return None
    return get_current_user(token=token, db=db)


def _resolve_worker_person_id(
    current_user,
) -> int | None:
    if current_user is None:
        return None
    person_id = getattr(current_user, "person_id", None)
    if person_id is None:
        return None
    return int(person_id)


@router.post(
    "/daily-work-plans",
    response_model=DailyWorkPlanResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_plan(
    payload: DailyWorkPlanCreateRequest,
    db: DbDep,
    current_user: CurrentUserDep,
):
    site = db.query(Site).filter(Site.id == payload.site_id).first()
    if site is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Site not found")

    plan = create_daily_work_plan(
        db,
        site_id=payload.site_id,
        work_date=payload.work_date,
        author_user_id=current_user.id,
    )
    return plan


@router.get("/daily-work-plans/{plan_id:int}", response_model=DailyWorkPlanResponse)
def get_plan(plan_id: int, db: DbDep, current_user: CurrentUserDep):
    plan = get_daily_work_plan(db, plan_id)
    if plan is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="DailyWorkPlan not found")
    return plan


@router.post(
    "/daily-work-plans/{plan_id:int}/items",
    response_model=DailyWorkPlanItemResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_plan_item(
    plan_id: int,
    payload: DailyWorkPlanItemCreateRequest,
    db: DbDep,
    current_user: CurrentUserDep,
):
    plan = get_daily_work_plan(db, plan_id)
    if plan is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="DailyWorkPlan not found")
    return create_daily_work_plan_item(
        db,
        plan_id=plan_id,
        work_name=payload.work_name,
        work_description=payload.work_description,
        team_label=payload.team_label,
        leader_person_id=payload.leader_person_id,
    )


@router.post(
    "/daily-work-plan-items/{item_id:int}/recommend-risks",
    response_model=RecommendRisksResponse,
)
def recommend_risks(
    item_id: int,
    payload: RecommendRisksRequest,
    db: DbDep,
    current_user: CurrentUserDep,
):
    try:
        result = run_recommendation_for_plan_item(
            db,
            plan_item_id=item_id,
            top_n=payload.top_n,
        )
    except ValueError as exc:
        if str(exc) == "plan_item_not_found":
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="DailyWorkPlanItem not found",
            )
        raise
    return RecommendRisksResponse(
        plan_item_id=item_id,
        recommended_count=result["recommended_count"],
        upserted_count=result["upserted_count"],
    )


@router.get(
    "/daily-work-plan-items/{item_id:int}/risk-refs",
    response_model=list[DailyWorkPlanItemRiskRefResponse],
)
def get_plan_item_risk_refs(item_id: int, db: DbDep, current_user: CurrentUserDep):
    item = db.query(DailyWorkPlanItem).filter(DailyWorkPlanItem.id == item_id).first()
    if item is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="DailyWorkPlanItem not found")
    refs = list_risk_refs_for_plan_item(db, plan_item_id=item_id)
    return refs


@router.post(
    "/daily-work-plan-items/{item_id:int}/adopt-risks",
    response_model=AdoptRisksResponse,
)
def adopt_risks(
    item_id: int,
    payload: AdoptRisksRequest,
    db: DbDep,
    current_user: CurrentUserDep,
):
    try:
        result = adopt_risks_for_plan_item_by_revision_ids(
            db,
            plan_item_id=item_id,
            risk_revision_ids=payload.risk_revision_ids,
        )
    except ValueError as exc:
        if str(exc) == "plan_item_not_found":
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="DailyWorkPlanItem not found",
            )
        raise
    return AdoptRisksResponse(
        plan_item_id=item_id,
        requested_count=result["requested_count"],
        adopted_count=result["adopted_count"],
    )


@router.post("/daily-work-plans/{plan_id:int}/confirm", response_model=DailyWorkPlanConfirmResponse)
def confirm_plan(plan_id: int, db: DbDep, current_user: CurrentUserDep):
    plan = get_daily_work_plan(db, plan_id)
    if plan is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="DailyWorkPlan not found")
    confirmation, created = confirm_daily_work_plan(
        db,
        plan_id=plan_id,
        confirmed_by_user_id=current_user.id,
    )
    return DailyWorkPlanConfirmResponse(
        plan_id=plan_id,
        confirmation_id=confirmation.id,
        created=created,
    )


@router.get(
    "/daily-work-plans/{plan_id:int}/confirmations",
    response_model=list[DailyWorkPlanConfirmationResponse],
)
def get_plan_confirmations(plan_id: int, db: DbDep, current_user: CurrentUserDep):
    plan = get_daily_work_plan(db, plan_id)
    if plan is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="DailyWorkPlan not found")
    return list_plan_confirmations(db, plan_id=plan_id)


@router.post(
    "/daily-work-plans/assemble-document",
    response_model=AssembleDailyWorkPlanDocumentResponse,
)
def assemble_work_plan_document(
    payload: AssembleDailyWorkPlanDocumentRequest,
    db: DbDep,
    current_user: CurrentUserDep,
):
    try:
        assembled = assemble_daily_work_plan_document(
            db,
            site_id=payload.site_id,
            work_date=payload.work_date,
            assembled_by_user_id=current_user.id,
        )
    except ValueError as exc:
        if str(exc) == "daily_work_plan_not_found":
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="DailyWorkPlan not found for site/work_date",
            )
        raise
    return AssembleDailyWorkPlanDocumentResponse(**assembled)


@router.get(
    "/daily-work-plans/assembled-document",
    response_model=GetAssembledDailyWorkPlanDocumentResponse,
)
def get_assembled_work_plan_document(
    site_id: int,
    work_date: date,
    db: DbDep,
    current_user: CurrentUserDep,
):
    try:
        assembled = get_assembled_document_for_day(
            db,
            site_id=site_id,
            work_date=work_date,
        )
    except ValueError as exc:
        if str(exc) == "assembled_document_not_found":
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Assembled document not found for site/work_date",
            )
        raise
    return GetAssembledDailyWorkPlanDocumentResponse(**assembled)


@router.post(
    "/daily-work-plans/distributions",
    response_model=DailyWorkPlanDistributionResponse,
    status_code=status.HTTP_201_CREATED,
)
def distribute_plan(
    payload: DailyWorkPlanDistributeRequest,
    db: DbDep,
    current_user: CurrentUserDep,
):
    try:
        result = distribute_daily_work_plan(
            db,
            plan_id=payload.plan_id,
            target_date=payload.target_date,
            visible_from=payload.visible_from,
            distributed_by_user_id=current_user.id,
            person_ids=payload.person_ids,
        )
    except ValueError as exc:
        if str(exc) == "daily_work_plan_not_found":
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="DailyWorkPlan not found")
        if str(exc) == "site_not_found":
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Site not found")
        raise
    return DailyWorkPlanDistributionResponse(**result)


@router.get(
    "/daily-work-plans/distributions/{distribution_id:int}",
    response_model=DailyWorkPlanDistributionDetailResponse,
)
def get_distribution(
    distribution_id: int,
    db: DbDep,
    current_user: CurrentUserDep,
):
    distribution = get_distribution_detail(db, distribution_id=distribution_id)
    if distribution is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Distribution not found")
    workers = list_distribution_workers(db, distribution_id=distribution_id)
    return DailyWorkPlanDistributionDetailResponse(
        id=distribution.id,
        plan_id=distribution.plan_id,
        site_id=distribution.site_id,
        target_date=distribution.target_date,
        visible_from=distribution.visible_from,
        distributed_by_user_id=distribution.distributed_by_user_id,
        distributed_at=distribution.distributed_at,
        status=distribution.status,
        tbm_started_at=distribution.tbm_started_at,
        tbm_started_by_user_id=distribution.tbm_started_by_user_id,
        is_tbm_active=distribution.tbm_started_at is not None,
        workers=workers,
    )


@router.post(
    "/daily-work-plans/distributions/{distribution_id:int}/start-tbm",
    response_model=StartTbmDistributionResponse,
)
def start_tbm_for_distribution(
    distribution_id: int,
    db: DbDep,
    current_user: CurrentUserDep,
):
    try:
        result = start_distribution_tbm(
            db,
            distribution_id=distribution_id,
            started_by_user_id=current_user.id,
        )
    except ValueError as exc:
        if str(exc) == "distribution_not_found":
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Distribution not found")
        raise
    return StartTbmDistributionResponse(**result)


@router.post(
    "/daily-work-plans/admin-presence/ping",
    response_model=SiteAdminPresencePingResponse,
)
def ping_admin_presence(
    payload: SiteAdminPresencePingRequest,
    db: DbDep,
    current_user: CurrentUserDep,
):
    try:
        presence = ping_site_admin_presence(
            db,
            user_id=current_user.id,
            site_id=payload.site_id,
            lat=payload.lat,
            lng=payload.lng,
        )
    except ValueError as exc:
        if str(exc) == "user_not_found":
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
        if str(exc) == "user_not_admin":
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin role required")
        raise
    return SiteAdminPresencePingResponse(
        site_id=presence.site_id,
        user_id=presence.user_id,
        last_seen_at=presence.last_seen_at,
    )


@router.get(
    "/worker/my-daily-work-plans",
    response_model=list[WorkerMyDailyWorkPlanListItem],
)
def list_my_daily_work_plans(
    db: DbDep,
    access_token: str | None = None,
    current_user=Depends(_get_optional_current_user),
):
    person_id = _resolve_worker_person_id(current_user)
    if not access_token and person_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Worker login or access_token is required",
        )
    rows = list_worker_visible_distributions(db, access_token=access_token, person_id=person_id)
    return [WorkerMyDailyWorkPlanListItem(**row) for row in rows]


@router.get(
    "/worker/my-daily-work-plans/{distribution_id:int}",
    response_model=WorkerMyDailyWorkPlanDetailResponse,
)
def get_my_daily_work_plan_detail(
    distribution_id: int,
    db: DbDep,
    access_token: str | None = None,
    current_user=Depends(_get_optional_current_user),
):
    person_id = _resolve_worker_person_id(current_user)
    if not access_token and person_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Worker login or access_token is required",
        )
    try:
        detail = get_worker_distribution_detail(
            db,
            distribution_id=distribution_id,
            access_token=access_token,
            person_id=person_id,
        )
    except ValueError as exc:
        if str(exc) == "distribution_worker_not_found":
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid distribution/token")
        if str(exc) == "distribution_not_found":
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Distribution not found")
        if str(exc) == "distribution_not_visible_yet":
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Distribution not visible yet")
        if str(exc) == "daily_work_plan_not_found":
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="DailyWorkPlan not found")
        raise
    return WorkerMyDailyWorkPlanDetailResponse(**detail)


@router.post(
    "/worker/my-daily-work-plans/{distribution_id:int}/sign",
    response_model=WorkerSignDailyWorkPlanResponse,
)
def sign_my_daily_work_plan(
    distribution_id: int,
    payload: WorkerSignDailyWorkPlanRequest,
    db: DbDep,
    current_user=Depends(_get_optional_current_user),
):
    person_id = _resolve_worker_person_id(current_user)
    if not payload.access_token and person_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Worker login or access_token is required",
        )
    try:
        result = sign_worker_daily_work_plan(
            db,
            distribution_id=distribution_id,
            access_token=payload.access_token,
            person_id=person_id,
            signature_data=payload.signature_data,
            signature_mime=payload.signature_mime,
            lat=payload.lat,
            lng=payload.lng,
        )
    except ValueError as exc:
        code = str(exc)
        detail_message = code
        if code == "tbm_not_started":
            detail_message = "아직 TBM이 시작되지 않았습니다. 관리자 안내 후 서명하세요."
        elif code == "worker_out_of_site_radius":
            detail_message = "관리자가 있는 TBM장소로 이동하여 서명하세요."
        if code in {
            "distribution_worker_not_found",
            "distribution_not_visible_yet",
            "already_signed",
            "already_end_signed",
            "start_signature_required",
            "tbm_not_started",
        }:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=detail_message)
        if code in {
            "invalid_signature_mime",
            "invalid_signature_prefix",
            "invalid_signature_base64",
            "signature_too_small",
            "signature_too_large",
            "site_location_not_configured",
            "invalid_end_status",
        }:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=detail_message)
        if code in {"worker_out_of_site_radius", "active_admin_presence_not_found"}:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=detail_message)
        if code in {"distribution_not_found", "site_not_found"}:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=detail_message)
        raise
    return WorkerSignDailyWorkPlanResponse(**result)


@router.post(
    "/worker/my-daily-work-plans/{distribution_id:int}/sign-start",
    response_model=WorkerSignDailyWorkPlanResponse,
)
def sign_my_daily_work_plan_start(
    distribution_id: int,
    payload: WorkerSignDailyWorkPlanRequest,
    db: DbDep,
    current_user=Depends(_get_optional_current_user),
):
    return sign_my_daily_work_plan(
        distribution_id=distribution_id,
        payload=payload,
        current_user=current_user,
        db=db,
    )


@router.post(
    "/worker/my-daily-work-plans/{distribution_id:int}/sign-end",
    response_model=WorkerSignDailyWorkPlanResponse,
)
def sign_my_daily_work_plan_end(
    distribution_id: int,
    payload: WorkerSignEndDailyWorkPlanRequest,
    db: DbDep,
    current_user=Depends(_get_optional_current_user),
):
    person_id = _resolve_worker_person_id(current_user)
    if not payload.access_token and person_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Worker login or access_token is required",
        )
    try:
        result = sign_worker_daily_work_plan_end(
            db,
            distribution_id=distribution_id,
            access_token=payload.access_token,
            person_id=person_id,
            end_status=payload.end_status,
            signature_data=payload.signature_data,
            signature_mime=payload.signature_mime,
            lat=payload.lat,
            lng=payload.lng,
        )
    except ValueError as exc:
        code = str(exc)
        detail_message = code
        if code == "tbm_not_started":
            detail_message = "아직 TBM이 시작되지 않았습니다. 관리자 안내 후 서명하세요."
        elif code == "worker_out_of_site_radius":
            detail_message = "관리자가 있는 TBM장소로 이동하여 서명하세요."
        if code in {
            "distribution_worker_not_found",
            "distribution_not_visible_yet",
            "already_end_signed",
            "start_signature_required",
            "tbm_not_started",
        }:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=detail_message)
        if code in {
            "invalid_signature_mime",
            "invalid_signature_prefix",
            "invalid_signature_base64",
            "signature_too_small",
            "signature_too_large",
            "site_location_not_configured",
            "invalid_end_status",
        }:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=detail_message)
        if code in {"worker_out_of_site_radius", "active_admin_presence_not_found"}:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=detail_message)
        if code in {"distribution_not_found", "site_not_found"}:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=detail_message)
        raise
    return WorkerSignDailyWorkPlanResponse(**result)
