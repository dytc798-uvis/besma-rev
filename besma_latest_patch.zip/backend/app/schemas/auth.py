from datetime import datetime

from pydantic import BaseModel


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenPayload(BaseModel):
    sub: str | None = None
    exp: datetime | None = None


class LoginRequest(BaseModel):
    login_id: str
    password: str


class UserMe(BaseModel):
    id: int
    name: str
    login_id: str
    role: str
    ui_type: str
    site_id: int | None
    person_id: int | None

    class Config:
        from_attributes = True

