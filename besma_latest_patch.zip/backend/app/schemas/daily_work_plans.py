from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


class DailyWorkPlanCreateRequest(BaseModel):
    site_id: int
    work_date: date


class DailyWorkPlanItemCreateRequest(BaseModel):
    work_name: str
    work_description: str
    team_label: str | None = None
    leader_person_id: int | None = None


class RecommendRisksRequest(BaseModel):
    top_n: int = Field(default=10, ge=1, le=50)


class RecommendRisksResponse(BaseModel):
    plan_item_id: int
    recommended_count: int
    upserted_count: int


class AdoptRisksRequest(BaseModel):
    risk_revision_ids: list[int]


class AdoptRisksResponse(BaseModel):
    plan_item_id: int
    requested_count: int
    adopted_count: int


class DailyWorkPlanItemRiskRefResponse(BaseModel):
    id: int
    plan_item_id: int
    risk_item_id: int
    risk_revision_id: int
    link_type: str
    is_selected: bool
    source_rule: str
    score: float
    display_order: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class DailyWorkPlanItemResponse(BaseModel):
    id: int
    plan_id: int
    work_name: str
    work_description: str
    team_label: str | None = None
    leader_person_id: int | None = None
    created_at: datetime
    risk_refs: list[DailyWorkPlanItemRiskRefResponse] = Field(default_factory=list)

    model_config = ConfigDict(from_attributes=True)


class DailyWorkPlanConfirmationResponse(BaseModel):
    id: int
    plan_id: int
    confirmed_by_user_id: int
    confirmed_at: datetime

    model_config = ConfigDict(from_attributes=True)


class DailyWorkPlanConfirmResponse(BaseModel):
    plan_id: int
    confirmation_id: int
    created: bool


class DailyWorkPlanResponse(BaseModel):
    id: int
    site_id: int
    work_date: date
    author_user_id: int
    status: str
    created_at: datetime
    updated_at: datetime
    items: list[DailyWorkPlanItemResponse] = Field(default_factory=list)
    confirmations: list[DailyWorkPlanConfirmationResponse] = Field(default_factory=list)

    model_config = ConfigDict(from_attributes=True)


class AssembleDailyWorkPlanDocumentRequest(BaseModel):
    site_id: int
    work_date: date


class AssembleDailyWorkPlanDocumentResponse(BaseModel):
    site_id: int
    work_date: date
    document_type_code: str
    instance_id: int
    document_id: int
    document_status: str
    workflow_status: str
    plan_count: int
    item_count: int
    adopted_risk_revision_count: int
    links_upserted: int


class AssembledPlanSummary(BaseModel):
    plan_id: int
    item_count: int
    adopted_risk_revision_count: int


class GetAssembledDailyWorkPlanDocumentResponse(BaseModel):
    site_id: int
    work_date: date
    instance_id: int
    document_id: int
    document_type_code: str
    workflow_status: str
    plans: list[AssembledPlanSummary] = Field(default_factory=list)


class DailyWorkPlanDistributeRequest(BaseModel):
    plan_id: int
    target_date: date
    visible_from: datetime
    person_ids: list[int] = Field(default_factory=list)


class DailyWorkPlanDistributionWorkerResponse(BaseModel):
    id: int
    distribution_id: int
    person_id: int
    employment_id: int | None = None
    access_token: str
    ack_status: str
    viewed_at: datetime | None = None
    start_signed_at: datetime | None = None
    end_signed_at: datetime | None = None
    end_status: str | None = None
    issue_flag: bool
    signed_at: datetime | None = None

    model_config = ConfigDict(from_attributes=True)


class DailyWorkPlanDistributionResponse(BaseModel):
    id: int
    plan_id: int
    site_id: int
    target_date: date
    visible_from: datetime
    distributed_by_user_id: int
    distributed_at: datetime
    status: str
    tbm_started_at: datetime | None = None
    tbm_started_by_user_id: int | None = None
    is_tbm_active: bool
    worker_count: int


class DailyWorkPlanDistributionDetailResponse(BaseModel):
    id: int
    plan_id: int
    site_id: int
    target_date: date
    visible_from: datetime
    distributed_by_user_id: int
    distributed_at: datetime
    status: str
    tbm_started_at: datetime | None = None
    tbm_started_by_user_id: int | None = None
    is_tbm_active: bool
    workers: list[DailyWorkPlanDistributionWorkerResponse] = Field(default_factory=list)


class StartTbmDistributionResponse(BaseModel):
    distribution_id: int
    tbm_started_at: datetime
    tbm_started_by_user_id: int
    is_tbm_active: bool


class WorkerMyDailyWorkPlanListItem(BaseModel):
    distribution_id: int
    plan_id: int
    site_id: int
    work_date: date
    visible_from: datetime
    ack_status: str
    viewed_at: datetime | None = None
    start_signed_at: datetime | None = None
    end_signed_at: datetime | None = None
    end_status: str | None = None
    issue_flag: bool
    signed_at: datetime | None = None


class WorkerMyDailyWorkPlanDetailResponse(BaseModel):
    distribution_worker_id: int
    distribution_id: int
    plan: DailyWorkPlanResponse
    ack_status: str
    viewed_at: datetime | None = None
    start_signed_at: datetime | None = None
    end_signed_at: datetime | None = None
    end_status: str | None = None
    issue_flag: bool
    signed_at: datetime | None = None
    is_completed: bool


class WorkerSignDailyWorkPlanRequest(BaseModel):
    access_token: str | None = None
    signature_data: str
    signature_mime: str
    lat: float
    lng: float


class WorkerSignDailyWorkPlanResponse(BaseModel):
    distribution_worker_id: int
    distribution_id: int
    ack_status: str
    viewed_at: datetime | None = None
    start_signed_at: datetime | None = None
    end_signed_at: datetime | None = None
    end_status: str | None = None
    issue_flag: bool
    signed_at: datetime | None = None
    signature_hash: str
    message: str | None = None


class WorkerSignEndDailyWorkPlanRequest(BaseModel):
    access_token: str | None = None
    end_status: str
    signature_data: str
    signature_mime: str
    lat: float
    lng: float


class SiteAdminPresencePingRequest(BaseModel):
    site_id: int
    lat: float | None = None
    lng: float | None = None


class SiteAdminPresencePingResponse(BaseModel):
    site_id: int
    user_id: int
    last_seen_at: datetime
